// This file is deprecated. Use src/config/firebase.js instead.
export { db, storage, auth } from '@/config/firebase';